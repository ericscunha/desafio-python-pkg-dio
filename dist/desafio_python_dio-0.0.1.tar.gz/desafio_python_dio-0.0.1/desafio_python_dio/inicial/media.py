def calc_media (a, b):
    # TODO: Complete os espaços em branco com as respectivas variáveis para o cálculo da média.
    media = ((a * 3.5) + (b * 7.5)) / 11

    # TODO: Complete com a variável que representa o resultado da média.
    return f'MEDIA = {media:.5f}'